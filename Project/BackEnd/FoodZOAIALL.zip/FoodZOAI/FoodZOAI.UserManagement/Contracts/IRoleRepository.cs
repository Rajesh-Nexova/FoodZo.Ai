﻿using FoodZOAI.UserManagement.Models;

namespace FoodZOAI.UserManagement.Contracts
{
    public class IRoleRepository
    {
       


    }
}
