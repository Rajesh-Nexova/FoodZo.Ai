﻿namespace FoodZOAI.UserManagement.Models
{
    public class ReminderUserDTO
    {
        public int ReminderId { get; set; }
        public int UserId { get; set; }
    }
}
