﻿namespace FoodZOAI.UserManagement.DTOs
{
    public class UserLoginRequestDTO
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
